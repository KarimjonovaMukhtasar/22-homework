export default class Movie {
  constructor(id, title, year) {
    this.id = id;
    this.title = title;
    this.year = year;
    this.actors = [];
  }
}
