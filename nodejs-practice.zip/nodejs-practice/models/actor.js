export default class Actor {
  constructor(id, name, age) {
    this.id = id;
    this.name = name;
    this.age = age;
  }
}
